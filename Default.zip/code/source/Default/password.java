package Default;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.passman.PasswordManagerException;
import com.wm.app.b2b.server.OutboundPasswordManager;
// --- <<IS-END-IMPORTS>> ---

public final class password

{
	// ---( internal utility methods )---

	final static password _instance = new password();

	static password _newInstance() { return new password(); }

	static password _cast(Object o) { return (password)o; }

	// ---( server methods )---




	public static final void getConnectionPassword (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getConnectionPassword)>> ---
		// @sigtype java 3.5
		// [i] field:0:required connectionName
		// [o] field:0:required password
		IDataCursor pipelineCursor = pipeline.getCursor();
		String   alias = IDataUtil.getString( pipelineCursor, "connectionName" );
		OutboundPasswordManager manager = new OutboundPasswordManager();
		try {
		            IDataUtil.put( pipelineCursor, "password", manager.retrievePassword("wm.is.art.password."+alias) );
		            pipelineCursor.destroy();          
		           
		} catch (PasswordManagerException e) {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		}
		// --- <<IS-END>> ---

                
	}
}

